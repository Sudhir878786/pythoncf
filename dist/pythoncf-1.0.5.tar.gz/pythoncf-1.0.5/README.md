# pythoncf

`pythoncf` is a command-line interface (CLI) tool for accessing and interacting with the Codeforces. It allows users to retrieve information about users, contests, problems, blogs, ratings, and more from Codeforces.

## Features

- **User Information**: Retrieve details about a specific Codeforces user.
- **Rating Graph**: Display the rating chart of a user.
- **Contest Information**: Get details about a specific contest.
- **Problem Retrieval**: Fetch all problems or filter by tags.
- **Blog Entries**: View specific blog entries and user blog entries.
- **Rating Changes**: Get the rating changes for a contest.
- **User Status**: Retrieve submission status of a user in a contest.
- **Contest Status**: Get the status of submissions in a contest.
- **User Comparison**: Compare two users' information.

## Installation

To install `pythoncf`, you can use `pip`:

```bash
pip install pythoncf
```
## Usage

The following examples illustrate the usage of `pythoncf`:

- **Display user details:**

    ```bash
    pythoncf -userinfo DJjwalababu
    ```

- **Display rating chart of a user:**

    ```bash
    pythoncf -graph DJjwalababu
    ```

- **Get details of a specific contest:**

    ```bash
    pythoncf -contestinfo 1921
    ```

- **Retrieve all problems:**

    ```bash
    pythoncf -prob
    ```

- **Retrieve problems with a specific tag:**

    ```bash
    pythoncf -prob --tag dp
    ```

- **View a specific blog entry:**

    ```bash
    pythoncf -b 1234
    ```

- **Get rating changes for a contest:**

    ```bash
    pythoncf -ratingchange 1921
    ```

- **Get rating changes for a contest with a specific handle:**

    ```bash
    pythoncf -ratingchange 1921 --handle DJjwalababu
    ```

- **Get blog entries of a user:**

    ```bash
    pythoncf -bu DJjwalababu
    ```

- **Get submissions of a specified user:**

    ```bash
    pythoncf -submission DJjwalababu
    ```

- **Get submissions with pagination:**

    ```bash
    pythoncf -submission DJjwalababu --fr 1 --count 10
    ```

- **Get contest submissions:**

    ```bash
    pythoncf -conteststatus 1921
    ```

- **Get contest submissions with pagination:**

    ```bash
    pythoncf -conteststatus 1921 --fr 1 --count 10
    ```

- **Compare two users:**

    ```bash
    pythoncf --compare DJjwalababu tourist
    ```

## Arguments

- `-userinfo`, `--user` `<HANDLE>`: Display user details.
- `-graph`, `--graph` `<HANDLE>`: Display the rating chart of a user.
- `-contestinfo`, `--contest` `<CONTEST ID>`: Get details of a contest.
- `--gym`: Optional argument to list gym contests (use with `-contestinfo`).
- `-prob`, `--problem`: Retrieve all problems.
- `--tag` `<TAG>`: Tag of problems to retrieve.
- `-b`, `--blog` `<BLOG ID>`: View a specific blog entry.
- `-ratingchange`, `--ratingchange` `<CONTEST ID>`: Get rating changes for a contest.
- `--handle` `<HANDLE>`: Specify a handle for rating change queries.
- `-bu`, `--bloguser` `<HANDLE>`: Get blog entries of a user.
- `-submission`, `--userstatus` `<HANDLE>`: Get submissions of a specified user.
- `--fr` `<FROM>`: 1-based index of the first submission to return.
- `--count` `<COUNT>`: Number of returned submissions.
- `-conteststatus`, `--cstatus` `<CONTEST ID>`: Get contest submissions.
- `--compare` `<USER1 USER2>`: Compare two users.



