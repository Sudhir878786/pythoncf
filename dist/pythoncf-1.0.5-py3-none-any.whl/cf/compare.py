from cf.util import *
from cf.classes import *
import matplotlib.pyplot as plt

def compare(res):
    res = res['result']
    u1 = User(res[0])
    u2 = User(res[1])

    # Data for pie chart
    labels = [u1.handle, u2.handle]
    sizes = [u1.rating, u2.rating]
    max_sizes = [u1.maxRating, u2.maxRating]

    # Create pie chart for ratings
    fig, ax = plt.subplots(1, 2, figsize=(14, 7))

    # Pie chart for Rating
    ax[0].pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140, colors=['blue', 'red'])
    ax[0].set_title('Rating Comparison')

    # Pie chart for Max Rating
    ax[1].pie(max_sizes, labels=labels, autopct='%1.1f%%', startangle=140, colors=['blue', 'red'])
    ax[1].set_title('Max Rating Comparison')

    # Show the plots
    plt.show()

    # Additional textual summary
    print("\n" + get_colored("Comparison Summary:", 'magenta'))
    print(get_colored("User 1 ({}):".format(u1.handle), 'cyan'))
    print(" - Rating: " + get_colored(str(u1.rating), 'blue'))
    print(" - Max Rating: " + get_colored(str(u1.maxRating), 'blue'))
    print("\n" + get_colored("User 2 ({}):".format(u2.handle), 'cyan'))
    print(" - Rating: " + get_colored(str(u2.rating), 'red'))
    print(" - Max Rating: " + get_colored(str(u2.maxRating), 'red'))

    print("\n" + get_colored("Pie charts generated using matplotlib.", 'green'))
